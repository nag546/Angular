export class AuthInfo {
  token: string;
  authenticated: boolean;
}
export class UserModel {
  UserName: string;
  Password: string;
}
